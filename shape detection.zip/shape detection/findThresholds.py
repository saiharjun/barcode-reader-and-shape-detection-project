import numpy as np
import cv2

def nothing(x):
    pass

cv2.namedWindow('image')

cv2.createTrackbar("A", "image", 0, 255, nothing)
cv2.createTrackbar("B", "image", 0, 255, nothing)

while(1):
    hu1 = cv2.getTrackbarPos("A", "image")
    hu2 = cv2.getTrackbarPos("B", "image")
    img = cv2.imread("leaf.jpeg")
    #imgGrey = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    ret, thresh = cv2.threshold(img, hu1, hu2, cv2.THRESH_BINARY)
    
    img = cv2.imshow("thresh", thresh)
    
    k = cv2.waitKey(1)&0xFF
    if k==27:
        break
    
cv2.destroyAllWindows()
